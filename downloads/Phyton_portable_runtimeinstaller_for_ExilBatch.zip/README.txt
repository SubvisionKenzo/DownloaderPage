#Français :

Ce projet utilise python et a été créé à l’origine pour ExilBatch.
Pour plus d’informations, rendez?vous sur :
https://subvisionkenzo.github.io/ExilbatchWeb/

Vous pouvez aussi l’utiliser directement en l’incluant dans vos applications Python.
Ce projet contient un environnement Python minimal : il suffit de déplacer vos fichiers .py ou de les lancer avec py.bat.

Vos programmes se lanceront automatiquement, et une boîte de dialogue apparaîtra en cas d’erreur dans le code.

#Anglish :

This project uses Python and was originally created for ExilBatch.
For more information, visit:
https://subvisionkenzo.github.io/ExilbatchWeb/

You can also use it directly by including it in your Python applications.
This project contains a minimal Python environment: simply move your .py files or run them using py.bat.

Your programs will launch automatically, and a dialog box will appear if there is an error in the code.

###########Python Licence###########

https://docs.python.org/3/license.html#otherlicenses