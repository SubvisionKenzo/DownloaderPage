@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

set "STARTMENU=%AppData%\Microsoft\Windows\Start Menu\Programs\ExilBatch"

if not exist "%STARTMENU%" (
    echo Premi�re installation...
    powershell.exe -ExecutionPolicy Bypass -File extract.ps1
    exit /b
)

:: Trouver le premier fichier dans le dossier
for %%f in ("%STARTMENU%\*") do (
    set "firstFile=%%~nxf"
    goto found
)

echo %STARTMENU%
pause
exit /b

:found
echo !firstFile!

:: Lire le contenu du fichier (chemin d'installation)
set /p installDir=<"%STARTMENU%\!firstFile!"

echo !installDir!
pause
:: Extraire le package
7z.exe x "install.package" -o"!installDir!" -y
exit /b