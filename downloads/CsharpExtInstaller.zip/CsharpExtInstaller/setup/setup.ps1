Add-Type -AssemblyName PresentationFramework

# --- Détection langue Windows ---
$winLang = (Get-Culture).Name.Split("-")[0].ToUpper()

# On mappe les langues Windows vers tes fichiers
switch ($winLang) {
    "FR" { $lang = "FR" }
    "ES" { $lang = "ES" }
    default { $lang = "UE" }
}

$langFile = ".\lang\$lang.lang"

# Si le fichier n'existe pas → fallback UE
if (!(Test-Path $langFile)) {
    $langFile = ".\lang\UE.lang"
}

# --- Lecture du fichier langue ---
$langData = @{}
Get-Content $langFile | ForEach-Object {
    if ($_ -match "^(.*?)=(.*)$") {
        $langData[$matches[1]] = $matches[2]
    }
}

# --- Vérification images ---
$imagePath = "image.png"
$logoPath  = "logo.png"

if (!(Test-Path $imagePath)) { $imagePath = "" }
if (!(Test-Path $logoPath))  { $logoPath  = "" }

# --- XAML Interface ---
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Setup"
        Height="480" Width="750"
        WindowStartupLocation="CenterScreen"
        ResizeMode="NoResize"
        Background="#f2f2f2">

    <Grid Margin="0">
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="220"/>
            <ColumnDefinition Width="*"/>
        </Grid.ColumnDefinitions>

        <!-- IMAGE À GAUCHE -->
        <Border Grid.Column="0" Background="#dddddd">
            <Image Name="ImgSide" Stretch="Uniform"/>
        </Border>

        <!-- CONTENU -->
        <StackPanel Grid.Column="1" Margin="20">

            <!-- LOGO -->
            <Image Name="ImgLogo" Height="60" Margin="0 0 0 10"/>

            <!-- TITRE -->
            <TextBlock Name="TxtTitle"
                       FontSize="24"
                       FontWeight="Bold"
                       Margin="0 0 0 15"/>

            <!-- BOX DE TEXTE -->
            <Border Background="White"
                    BorderBrush="#c0c0c0"
                    BorderThickness="1"
                    CornerRadius="4"
                    Padding="10"
                    Margin="0 0 0 10">
                <ScrollViewer VerticalAlignment="Stretch">
                <TextBox Name="TxtMessage"
                         TextWrapping="Wrap"
                         FontSize="14"
                         IsReadOnly="True"
                         Background="Transparent"
                         BorderThickness="0"
                         AcceptsReturn="True"
                         VerticalScrollBarVisibility="Auto"/>
                </ScrollViewer>
            </Border>

        </StackPanel>

        <!-- BANDEAU BAS -->
        <DockPanel Grid.ColumnSpan="2"
                   VerticalAlignment="Bottom"
                   Background="#c9c9c9"
                   Height="60"
                   LastChildFill="False">

            <Button Name="BtnInstall"
                    Width="140" Height="38"
                    Margin="10"
                    HorizontalAlignment="Right"
                    DockPanel.Dock="Right"
                    Background="#4CAF50"
                    Foreground="White"
                    FontWeight="Bold"/>
        </DockPanel>

    </Grid>
</Window>
"@

# --- Chargement XAML ---
$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

# --- Injection du texte ---
$window.FindName("TxtTitle").Text   = $langData["TITLE"]
$message = $langData["MESSAGE"].Replace("\n", "`n")
$window.FindName("TxtMessage").Text = $message
$window.FindName("BtnInstall").Content = $langData["BUTTON"]

# --- Images si présentes ---
if ($imagePath -ne "") {
    $window.FindName("ImgSide").Source = $imagePath
}
if ($logoPath -ne "") {
    $window.FindName("ImgLogo").Source = $logoPath
}

# --- Action du bouton INSTALLER ---
$window.FindName("BtnInstall").Add_Click({
    Start-Process ".\install.bat"
    $window.Close()
})

# --- Affichage ---
$window.ShowDialog() | Out-Null