Add-Type -AssemblyName System.Windows.Forms

# --- Choisir le dossier d'installation ---
$folderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
$folderDialog.Description = "Installation Setup (Extract)"
$folderDialog.ShowNewFolderButton = $true

if ($folderDialog.ShowDialog() -ne "OK") {
    Write-Host "Installation annul�e."
    exit
}

$installDir = $folderDialog.SelectedPath
Write-Host "Installation dans : $installDir"

# --- V�rifier le fichier package ---
$package = Join-Path $PSScriptRoot "install.package"

if (-not (Test-Path $package)) {
    Write-Host "ERREUR : install.package introuvable."
    exit
}

# --- Test ZIP ---
try {
    Expand-Archive -Path $package -DestinationPath $installDir -Force
    Write-Host "Extraction ZIP r�ussie !"
    exit
}
catch {
    Write-Host "Ce n'est pas un ZIP valide, tentative avec 7zip..."
}

# --- Extraction via 7zip ---
$sevenZip = Join-Path $PSScriptRoot "7z.exe"

if (-not (Test-Path $sevenZip)) {
    Write-Host "ERREUR : 7z.exe introuvable. Impossible d'extraire."
    exit
}

& $sevenZip x $package "-o$installDir" -y

Write-Host "Extraction termin�e via 7zip !"