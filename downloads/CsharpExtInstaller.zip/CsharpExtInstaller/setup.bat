@echo off
cd /d "%~dp0"
set "name=setup"
set "hide=%random%"
if exist %hide%.txt goto execut
echo >> %hide%.txt
cmd /c start /min setup.bat %hide%
exit
:execut
del %1.txt
cd setup
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul