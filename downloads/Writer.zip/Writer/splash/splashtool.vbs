On Error Resume Next

Set shell = CreateObject("WScript.Shell")

' V�rifier l'association du .hta
htaAssoc = ""
htaAssoc = shell.RegRead("HKEY_CLASSES_ROOT\.hta\")

If Err.Number <> 0 Or htaAssoc = "" Then
    Err.Clear

    ' Recr�er l'association HTA -> mshta.exe
    shell.RegWrite "HKEY_CLASSES_ROOT\.hta\", "htafile", "REG_SZ"
    shell.RegWrite "HKEY_CLASSES_ROOT\htafile\shell\open\command\", _
        """C:\Windows\System32\mshta.exe"" ""%1"" %*", "REG_SZ"
End If

' Lancer le splash VISIBILEMENT
shell.Run "mshta.exe ""splash.hta""", 1, False