@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
del ready.txt
exit