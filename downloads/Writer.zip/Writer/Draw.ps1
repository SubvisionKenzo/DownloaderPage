Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName Microsoft.VisualBasic   # Correction InputBox

# =========================
#   PARAM�TRES DE BASE
# =========================

$LargeurInitiale = 800
$HauteurInitiale = 800

# --- �tats globaux ---
$global:Bitmap = New-Object System.Drawing.Bitmap $LargeurInitiale, $HauteurInitiale
$g = [System.Drawing.Graphics]::FromImage($global:Bitmap)
$g.Clear([System.Drawing.Color]::White)
$g.Dispose()

$global:OutilActif      = "Pinceau"
$global:CouleurActuelle = [System.Drawing.Color]::Black
$global:TaillePinceau   = 2
$global:CheminFichier   = $null

# Undo / Redo
$global:UndoStack = New-Object System.Collections.Stack
$global:RedoStack = New-Object System.Collections.Stack
$MaxUndo = 30

# =========================
#   Splash sscreen
# =========================

# Aller dans le dossier splash
$splashPath = Join-Path $PSScriptRoot "splash"

# S'assurer que le dossier existe
if (-not (Test-Path $splashPath)) {
    New-Item -ItemType Directory -Path $splashPath | Out-Null
}

# Ton programme se charge ici...
Start-Sleep -Seconds 3  # exemple

# Quand tout est pr�t -> cr�er ready.txt
$readyFile = Join-Path $splashPath "ready.txt"
"READY=1" | Out-File -FilePath $readyFile -Encoding UTF8

# =========================
#   FONCTIONS UTILITAIRES
# =========================

function Copy-Bitmap($bmp) {
    $copy = New-Object System.Drawing.Bitmap $bmp.Width, $bmp.Height
    $g = [System.Drawing.Graphics]::FromImage($copy)
    $g.DrawImage($bmp, 0, 0)
    $g.Dispose()
    return $copy
}

function Push-Undo {
    param([System.Drawing.Bitmap]$bmp)

    if ($UndoStack.Count -ge $MaxUndo) {
        $temp = New-Object System.Collections.Stack
        while ($UndoStack.Count -gt 1) {
            $temp.Push($UndoStack.Pop())
        }
        $null = $UndoStack.Pop()
        while ($temp.Count -gt 0) {
            $UndoStack.Push($temp.Pop())
        }
    }

    $UndoStack.Push((Copy-Bitmap $bmp))
    $RedoStack.Clear()
}

function Undo {
    if ($UndoStack.Count -gt 0) {
        $RedoStack.Push((Copy-Bitmap $global:Bitmap))
        $global:Bitmap.Dispose()
        $global:Bitmap = $UndoStack.Pop()
        Refresh-Image
    }
}

function Redo {
    if ($RedoStack.Count -gt 0) {
        $UndoStack.Push((Copy-Bitmap $global:Bitmap))
        $global:Bitmap.Dispose()
        $global:Bitmap = $RedoStack.Pop()
        Refresh-Image
    }
}

function Convert-BitmapToImageSource($bmp) {
    $ms = New-Object System.IO.MemoryStream
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $ms.Position = 0

    $img = New-Object System.Windows.Media.Imaging.BitmapImage
    $img.BeginInit()
    $img.StreamSource = $ms
    $img.CacheOption = "OnLoad"
    $img.EndInit()
    return $img
}

# Flood-fill s�curis�
function Flood-Fill {
    param(
        [int]$x,
        [int]$y,
        [System.Drawing.Color]$targetColor,
        [System.Drawing.Color]$replacementColor
    )

    if ($targetColor.ToArgb() -eq $replacementColor.ToArgb()) { return }

    $w = $global:Bitmap.Width
    $h = $global:Bitmap.Height

    $stack = New-Object System.Collections.Stack
    $stack.Push([System.Drawing.Point]::new($x, $y))

    while ($stack.Count -gt 0) {
        $pt = $stack.Pop()
        $px = $pt.X
        $py = $pt.Y

        if ($px -lt 0 -or $px -ge $w -or $py -lt 0 -or $py -ge $h) { continue }

        $c = $global:Bitmap.GetPixel($px, $py)
        if ($c.ToArgb() -ne $targetColor.ToArgb()) { continue }

        $global:Bitmap.SetPixel($px, $py, $replacementColor)

        $stack.Push([System.Drawing.Point]::new($px+1, $py))
        $stack.Push([System.Drawing.Point]::new($px-1, $py))
        $stack.Push([System.Drawing.Point]::new($px, $py+1))
        $stack.Push([System.Drawing.Point]::new($px, $py-1))
    }
}

# =========================
#   FEN�TRE PRINCIPALE
# =========================

$Window = New-Object System.Windows.Window
$Window.Title = "Draw"
$Window.Width = 1000
$Window.Height = 800
$Window.Background = "#333333"
$Window.Icon = New-Object System.Drawing.Icon("icons\Sheet.ico")
$Window.WindowStartupLocation = "CenterScreen"

$Dock = New-Object System.Windows.Controls.DockPanel
$Window.Content = $Dock

# =========================
#   BARRE D'OUTILS
# =========================

$Toolbar = New-Object System.Windows.Controls.StackPanel
$Toolbar.Orientation = "Horizontal"
$Toolbar.Background = "#222222"
$Toolbar.Height = 40
$Toolbar.Margin = "0,0,0,5"
[System.Windows.Controls.DockPanel]::SetDock($Toolbar, "Top")
$Dock.Children.Add($Toolbar)

function New-ToolButton($iconName) {
    $img = New-Object System.Windows.Controls.Image
    $img.Source = [System.Windows.Media.Imaging.BitmapImage]::new(
        (New-Object System.Uri("$PSScriptRoot/icons/$iconName.png"))
    )
    $img.Width = 22
    $img.Height = 22

    $btn = New-Object System.Windows.Controls.Button
    $btn.Content = $img
    $btn.Margin = "5"
    $btn.Padding = "5"
    $btn.Background = "#333333"
    $btn.BorderBrush = "#555555"
    return $btn
}

$BtnNouveau     = New-ToolButton "new"
$BtnOuvrir      = New-ToolButton "open"
$BtnEnregistrer = New-ToolButton "save"
$BtnUndo        = New-ToolButton "undo"
$BtnRedo        = New-ToolButton "redo"
$BtnPinceau     = New-ToolButton "brush"
$BtnGomme       = New-ToolButton "eraser"
$BtnSeau        = New-ToolButton "bucket"
$BtnCouleur     = New-ToolButton "color"
$BtnTaille      = New-ToolButton "size"
$BtnRedim       = New-ToolButton "resize"

$Toolbar.Children.Add($BtnNouveau)
$Toolbar.Children.Add($BtnOuvrir)
$Toolbar.Children.Add($BtnEnregistrer)
$Toolbar.Children.Add($BtnUndo)
$Toolbar.Children.Add($BtnRedo)
$Toolbar.Children.Add($BtnPinceau)
$Toolbar.Children.Add($BtnGomme)
$Toolbar.Children.Add($BtnSeau)
$Toolbar.Children.Add($BtnCouleur)
$Toolbar.Children.Add($BtnTaille)
$Toolbar.Children.Add($BtnRedim)

# =========================
#   PALETTE DE COULEURS
# =========================

$Palette = New-Object System.Windows.Controls.StackPanel
$Palette.Orientation = "Horizontal"
$Palette.Background = "#222222"
$Palette.Height = 35
$Palette.Margin = "0,0,0,5"
[System.Windows.Controls.DockPanel]::SetDock($Palette, "Top")
$Dock.Children.Add($Palette)

function New-ColorButton([System.Drawing.Color]$color) {
    $btn = New-Object System.Windows.Controls.Button
    $btn.Width = 24
    $btn.Height = 24
    $btn.Margin = "4"
    $btn.BorderBrush = "#555555"
    $btn.Background = [System.Windows.Media.SolidColorBrush]::new(
        [System.Windows.Media.Color]::FromArgb($color.A, $color.R, $color.G, $color.B)
    )
    $btn.Tag = $color
    return $btn
}

$colors = @(
    [System.Drawing.Color]::Black,
    [System.Drawing.Color]::White,
    [System.Drawing.Color]::Red,
    [System.Drawing.Color]::Green,
    [System.Drawing.Color]::Blue,
    [System.Drawing.Color]::Yellow,
    [System.Drawing.Color]::Orange,
    [System.Drawing.Color]::Purple,
    [System.Drawing.Color]::Cyan,
    [System.Drawing.Color]::Brown
)

foreach ($c in $colors) {
    $btn = New-ColorButton $c
    $btn.Add_Click({
        $global:CouleurActuelle = [System.Drawing.Color]$this.Tag
    })
    $Palette.Children.Add($btn)
}

# =========================
#   ZONE DE DESSIN
# =========================

$Scroll = New-Object System.Windows.Controls.ScrollViewer
$Scroll.VerticalScrollBarVisibility = "Auto"
$Scroll.HorizontalScrollBarVisibility = "Auto"
$Scroll.Background = "#1a1a1a"
$Dock.Children.Add($Scroll)

$ImageControl = New-Object System.Windows.Controls.Image
$ImageControl.Margin = 10

$Scale = New-Object System.Windows.Media.ScaleTransform 1, 1
$TransformGroup = New-Object System.Windows.Media.TransformGroup
$TransformGroup.Children.Add($Scale)
$ImageControl.LayoutTransform = $TransformGroup

$Scroll.Content = $ImageControl

function Refresh-Image {
    $ImageControl.Source = Convert-BitmapToImageSource $global:Bitmap
}

Refresh-Image

# =========================
#   CURSEUR
# =========================

$ImageControl.Add_MouseEnter({
    switch ($global:OutilActif) {
        "Pinceau" { $Window.Cursor = [System.Windows.Input.Cursors]::Pen }
        "Gomme"   { $Window.Cursor = [System.Windows.Input.Cursors]::Cross }
        "Seau"    { $Window.Cursor = [System.Windows.Input.Cursors]::Hand }
        default   { $Window.Cursor = [System.Windows.Input.Cursors]::Arrow }
    }
})

$ImageControl.Add_MouseLeave({
    $Window.Cursor = [System.Windows.Input.Cursors]::Arrow
})

# =========================
#   DESSIN (CLICK + DRAG)
# =========================

function Dessiner-AuPoint {
    param(
        [int]$x,
        [int]$y
    )

    if ($x -lt 0 -or $x -ge $global:Bitmap.Width -or $y -lt 0 -or $y -ge $global:Bitmap.Height) { return }

    if ($global:OutilActif -eq "Pinceau") {
        for ($i = -$global:TaillePinceau; $i -le $global:TaillePinceau; $i++) {
            for ($j = -$global:TaillePinceau; $j -le $global:TaillePinceau; $j++) {
                $px = $x + $i
                $py = $y + $j
                if ($px -ge 0 -and $px -lt $global:Bitmap.Width -and $py -ge 0 -and $py -lt $global:Bitmap.Height) {
                    $global:Bitmap.SetPixel($px, $py, $global:CouleurActuelle)
                }
            }
        }
    }
    elseif ($global:OutilActif -eq "Gomme") {
        for ($i = -$global:TaillePinceau; $i -le $global:TaillePinceau; $i++) {
            for ($j = -$global:TaillePinceau; $j -le $global:TaillePinceau; $j++) {
                $px = $x + $i
                $py = $y + $j
                if ($px -ge 0 -and $px -lt $global:Bitmap.Width -and $py -ge 0 -and $py -lt $global:Bitmap.Height) {
                    $global:Bitmap.SetPixel($px, $py, [System.Drawing.Color]::White)
                }
            }
        }
    }
}

$ImageControl.Add_MouseDown({
    param($sender, $e)

    $pos = $e.GetPosition($ImageControl)
    $x = [int]($pos.X / $Scale.ScaleX)
    $y = [int]($pos.Y / $Scale.ScaleY)

    # S�curit� anti-crash
    if ($x -lt 0 -or $x -ge $global:Bitmap.Width -or $y -lt 0 -or $y -ge $global:Bitmap.Height) {
        return
    }

    Push-Undo $global:Bitmap

    if ($global:OutilActif -eq "Seau") {
        $target = $global:Bitmap.GetPixel($x, $y)
        Flood-Fill -x $x -y $y -targetColor $target -replacementColor $global:CouleurActuelle
    }
    else {
        Dessiner-AuPoint -x $x -y $y
    }

    Refresh-Image
})

$ImageControl.Add_MouseMove({
    param($sender, $e)

    if ($e.LeftButton -eq [System.Windows.Input.MouseButtonState]::Pressed -and $global:OutilActif -ne "Seau") {
        $pos = $e.GetPosition($ImageControl)
        $x = [int]($pos.X / $Scale.ScaleX)
        $y = [int]($pos.Y / $Scale.ScaleY)

        Dessiner-AuPoint -x $x -y $y
        Refresh-Image
    }
})

# =========================
#   ZOOM
# =========================

$Window.Add_MouseWheel({
    param($sender, $e)

    if ($e.Delta -gt 0) {
        $Scale.ScaleX += 0.1
        $Scale.ScaleY += 0.1
    }
    else {
        if ($Scale.ScaleX -gt 0.2) {
            $Scale.ScaleX -= 0.1
            $Scale.ScaleY -= 0.1
        }
    }
})

# =========================
#   BOUTONS OUTILS
# =========================

$BtnColorTool.Add_Click({
    $batPath = Join-Path $PSScriptRoot "color\window.bat"

    if (Test-Path $batPath) {
        Start-Process $batPath
    }
    else {
        [System.Windows.MessageBox]::Show("Le fichier 'color\window.bat' est introuvable.","Erreur")
    }
})

$BtnPinceau.Add_Click({
    $global:OutilActif = "Pinceau"
    $Window.Cursor = [System.Windows.Input.Cursors]::Pen
})

$BtnGomme.Add_Click({
    $global:OutilActif = "Gomme"
    $Window.Cursor = [System.Windows.Input.Cursors]::Cross
})

$BtnSeau.Add_Click({
    $global:OutilActif = "Seau"
    $Window.Cursor = [System.Windows.Input.Cursors]::Hand
})

$BtnCouleur.Add_Click({
    $dialog = New-Object System.Windows.Forms.ColorDialog
    if ($dialog.ShowDialog() -eq "OK") {
        $global:CouleurActuelle = $dialog.Color
    }
})

$BtnTaille.Add_Click({
    $input = [Microsoft.VisualBasic.Interaction]::InputBox(
        "Taille du pinceau (0 � 60)", 
        "Taille du pinceau", 
        $global:TaillePinceau
    )

    if ($input -match '^\d+$') {
        $val = [int]$input
        if ($val -ge 0 -and $val -le 60) {
            $global:TaillePinceau = $val
        }
    }
})

$BtnRedim.Add_Click({
    $input = [Microsoft.VisualBasic.Interaction]::InputBox(
        "Nouvelle taille (ex: 800 pour 800x800)", 
        "Redimensionner la feuille", 
        $global:Bitmap.Width
    )

    if ($input -match '^\d+$') {
        $newSize = [int]$input

        Push-Undo $global:Bitmap

        $newBmp = New-Object System.Drawing.Bitmap $newSize, $newSize
        $g = [System.Drawing.Graphics]::FromImage($newBmp)
        $g.Clear([System.Drawing.Color]::White)
        $g.DrawImage($global:Bitmap, 0, 0)
        $g.Dispose()

        $global:Bitmap.Dispose()
        $global:Bitmap = $newBmp
        Refresh-Image
    }
})

# =========================
#   FICHIERS / UNDO / REDO
# =========================

$BtnNouveau.Add_Click({
    Push-Undo $global:Bitmap
    $g = [System.Drawing.Graphics]::FromImage($global:Bitmap)
    $g.Clear([System.Drawing.Color]::White)
    $g.Dispose()
    $global:CheminFichier = $null
    Refresh-Image
})

$BtnOuvrir.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = "Image PNG|*.png"
    if ($dialog.ShowDialog() -eq "OK") {
        Push-Undo $global:Bitmap
        $img = [System.Drawing.Image]::FromFile($dialog.FileName)
        $global:Bitmap.Dispose()
        $global:Bitmap = New-Object System.Drawing.Bitmap $img
        $img.Dispose()
        $global:CheminFichier = $dialog.FileName
        Refresh-Image
    }
})

$BtnEnregistrer.Add_Click({
    if (-not $global:CheminFichier) {
        $dialog = New-Object System.Windows.Forms.SaveFileDialog
        $dialog.Filter = "Image PNG|*.png"
        $dialog.FileName = "mon_image.png"
        if ($dialog.ShowDialog() -eq "OK") {
            $global:CheminFichier = $dialog.FileName
        }
    }

    if ($global:CheminFichier) {
        $global:Bitmap.Save($global:CheminFichier, [System.Drawing.Imaging.ImageFormat]::Png)
    }
})

# --- Bouton Undo ---
$BtnUndo.Add_Click({
    Undo
})

# --- Bouton Redo ---
$BtnRedo.Add_Click({
    Redo
})

# =========================
#   LANCEMENT DE LA FEN�TRE
# =========================

$null = $Window.ShowDialog()
