Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Charger ta DLL MiniODS
Add-Type -Path "$PSScriptRoot\libs\MiniODS.dll"

# =========================
#   Splash sscreen
# =========================

# Aller dans le dossier splash
$splashPath = Join-Path $PSScriptRoot "splash"

# S'assurer que le dossier existe
if (-not (Test-Path $splashPath)) {
    New-Item -ItemType Directory -Path $splashPath | Out-Null
}

# Ton programme se charge ici...
Start-Sleep -Seconds 3  # exemple

# Quand tout est pr�t -> cr�er ready.txt
$readyFile = Join-Path $splashPath "ready.txt"
"READY=1" | Out-File -FilePath $readyFile -Encoding UTF8

# Cr�er la fen�tre
$form = New-Object System.Windows.Forms.Form
$form.Icon = New-Object System.Drawing.Icon("$PSScriptRoot\icons\Sheet.ico")
$form.Text = "Calc Ultra"
$form.Width = 1000
$form.Height = 700
$form.BackColor = [System.Drawing.Color]::FromArgb(240,255,240)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = New-Object System.Drawing.Size(900,600)
$toolbar = New-Object System.Windows.Forms.ToolStrip
$toolbar.Dock = "Top"
$toolbar.BackColor = [System.Drawing.Color]::FromArgb(220,245,220)
$toolbar.GripStyle = "Hidden"

function Add-IconButton($text, $iconPath) {
    $btn = New-Object System.Windows.Forms.ToolStripButton
    $btn.DisplayStyle = "Image"
    $btn.Image = [System.Drawing.Image]::FromFile($iconPath)
    $btn.ToolTipText = $text
    return $btn
}

$btnNew  = Add-IconButton "Nouveau"    "$PSScriptRoot\icons\new.png"
$btnOpen = Add-IconButton "Ouvrir"     "$PSScriptRoot\icons\open.png"
$btnSave = Add-IconButton "Enregistrer" "$PSScriptRoot\icons\save.png"
$btnColor = Add-IconButton "Couleur"   "$PSScriptRoot\icons\color.png"

$toolbar.Items.Add($btnNew)  | Out-Null
$toolbar.Items.Add($btnOpen) | Out-Null
$toolbar.Items.Add($btnSave) | Out-Null
$toolbar.Items.Add($btnColor)| Out-Null

$form.Controls.Add($toolbar)
$formulaBox = New-Object System.Windows.Forms.TextBox
$formulaBox.Width = 1150
$formulaBox.Top = $toolbar.Height + 10
$formulaBox.Left = 10
$formulaBox.Font = "Segoe UI, 11"
$formulaBox.Anchor = "Top, Left, Right"
$form.Controls.Add($formulaBox)
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Top = $formulaBox.Top + $formulaBox.Height + 5
$grid.Left = 10
$grid.Width = 1150
$grid.Height = 700
$grid.Anchor = "Top, Left, Right, Bottom"
$grid.AllowUserToAddRows = $false
$grid.RowHeadersWidth = 60
$grid.Font = "Segoe UI, 10"
$grid.BackgroundColor = "White"
$grid.GridColor = [System.Drawing.Color]::FromArgb(180,220,180)
$grid.BorderStyle = "FixedSingle"

# En-t�tes colonnes
$grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(0,150,80)
$grid.ColumnHeadersDefaultCellStyle.ForeColor = "White"
$grid.ColumnHeadersDefaultCellStyle.Font = "Segoe UI, 10, Bold"
$grid.EnableHeadersVisualStyles = $false

# En-t�tes lignes
$grid.RowHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(220,245,220)
$grid.RowHeadersDefaultCellStyle.ForeColor = "Black"
$grid.RowHeadersDefaultCellStyle.Font = "Segoe UI, 9"

$form.Controls.Add($grid)
$doc = New-Object MiniODS.OdsDocument
$sheet = New-Object MiniODS.OdsSheet("Feuille1", 200, 50)
$doc.Sheets.Add($sheet)
for ($c = 0; $c -lt 50; $c++) {
    $col = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $col.HeaderText = [char](65 + $c)
    $grid.Columns.Add($col)
}

for ($r = 0; $r -lt 200; $r++) {
    $grid.Rows.Add() | Out-Null
    $grid.Rows[$r].HeaderCell.Value = ($r + 1)
}
$grid.add_CellEndEdit({
    param($sender, $e)

    $row = $e.RowIndex
    $col = $e.ColumnIndex

    $value = $grid.Rows[$row].Cells[$col].Value
    $cell = $sheet.Cells[$row, $col]

    if ($value -is [string] -and $value.StartsWith("=")) {
        $cell.Formula = $value
        $cell.Text = $null
        $cell.Number = $null

        try {
            $result = [MiniODS.MiniCalc]::EvaluateFormula($value, $sheet)
            if ($result -ne $null) {
                $cell.Number = $result
                $grid.Rows[$row].Cells[$col].Value = $result
            }
        }
        catch {
            $grid.Rows[$row].Cells[$col].Value = $_.Exception.Message
            $cell.Text = $_.Exception.Message
        }
    }
    elseif ($value -as [double]) {
        $cell.Number = [double]$value
        $cell.Text = $null
        $cell.Formula = $null
    }
    else {
        $cell.Text = [string]$value
        $cell.Number = $null
        $cell.Formula = $null
    }
})
$btnOpen.add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "Fichiers ODS|*.ods"
    if ($dlg.ShowDialog() -eq "OK") {
        $doc.Load($dlg.FileName)
        # TODO : remplir la grille depuis $doc
    }
})

$btnSave.add_Click({
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = "Fichiers ODS|*.ods"
    if ($dlg.ShowDialog() -eq "OK") {
        $doc.Save($dlg.FileName)
    }
})
$btnColor.add_Click({
    $dlg = New-Object System.Windows.Forms.ColorDialog
    if ($dlg.ShowDialog() -eq "OK") {
        $grid.CurrentCell.Style.BackColor = $dlg.Color

        $row = $grid.CurrentCell.RowIndex
        $col = $grid.CurrentCell.ColumnIndex
        $sheet.Cells[$row, $col].BackgroundColor = "#" + $dlg.Color.ToArgb().ToString("X8").Substring(2)
    }
})
$form.ShowDialog()