Add-Type -AssemblyName PresentationCore, PresentationFramework, WindowsBase
Add-Type -AssemblyName System.Windows.Forms

# =========================
#   Splash sscreen
# =========================

# Aller dans le dossier splash
$splashPath = Join-Path $PSScriptRoot "splash"

# S'assurer que le dossier existe
if (-not (Test-Path $splashPath)) {
    New-Item -ItemType Directory -Path $splashPath | Out-Null
}

# Ton programme se charge ici...
Start-Sleep -Seconds 3  # exemple

# Quand tout est prêt -> créer ready.txt
$readyFile = Join-Path $splashPath "ready.txt"
"READY=1" | Out-File -FilePath $readyFile -Encoding UTF8

$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path

# ---------- 1. CHARGEMENT CONFIG / THEMES / TOOLBAR ----------

$script:ConfigPath = Join-Path $Root "config.txt"
$script:Config = @{}
if (Test-Path $ConfigPath) {
    Get-Content $ConfigPath | Where-Object {$_ -match "="} | ForEach-Object {
        $k, $v = $_ -split "=", 2
        $script:Config[$k.Trim()] = $v.Trim()
    }
} else {
    $script:Config["TITLE"] = "Writer"
    $script:Config["THEME"] = "dark"
    $script:Config["AUTOSAVE_INTERVAL"] = "30"
    $script:Config["SHOW_STATUSBAR"] = "true"
    $script:Config["SHOW_TOOLBAR"] = "true"
}

$script:ToolbarConfigPath = Join-Path $Root "toolbar.json"
if (Test-Path $ToolbarConfigPath) {
    $script:ToolbarConfig = Get-Content $ToolbarConfigPath -Raw | ConvertFrom-Json
} else {
    $script:ToolbarConfig = [pscustomobject]@{
        buttons = @("new","open","save","bold","italic","textcolor","highlight","alignleft","aligncenter","alignright","insertimage")
    }
}

$script:ThemePath = Join-Path $Root "theme.json"
if (Test-Path $ThemePath) {
    $script:Theme = Get-Content $ThemePath -Raw | ConvertFrom-Json
} else {
    $script:Theme = [pscustomobject]@{
        light = [pscustomobject]@{
            window_bg = "#FFFFFF"
            editor_bg = "#FFFFFF"
            editor_fg = "#000000"
            toolbar_bg = "#E0E0E0"
            status_bg  = "#F0F0F0"
        }
        dark = [pscustomobject]@{
            window_bg = "#1E1E1E"
            editor_bg = "#2A2A2A"
            editor_fg = "#FFFFFF"
            toolbar_bg = "#333333"
            status_bg  = "#2A2A2A"
        }
    }
}

$script:AutoSaveFolder = Join-Path $Root "autosave"
if (-not (Test-Path $AutoSaveFolder)) {
    New-Item -ItemType Directory -Path $AutoSaveFolder | Out-Null
}

# ---------- 2. CHARGEMENT XAML ----------

$xamlPath = Join-Path $Root "ui\window.xaml"
[xml]$xaml = Get-Content $xamlPath -Raw
$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

$window.Title = $Config["TITLE"]

$Tabs          = $window.FindName("Tabs")
$Toolbar       = $window.FindName("MainToolbar")
$StatusWords   = $window.FindName("StatusWords")
$StatusPos     = $window.FindName("StatusPos")
$MenuNew       = $window.FindName("MenuNew")
$MenuOpen      = $window.FindName("MenuOpen")
$MenuSave      = $window.FindName("MenuSave")
$MenuQuit      = $window.FindName("MenuQuit")
$MenuCopy      = $window.FindName("MenuCopy")
$MenuPaste     = $window.FindName("MenuPaste")
$MenuCut       = $window.FindName("MenuCut")
$MenuCustomizeToolbar = $window.FindName("MenuCustomizeToolbar")

# ---------- 3. APPLICATION DU THÈME ----------

function Apply-Theme {
    param($themeName)

    $t = $Theme.$themeName
    if (-not $t) { $t = $Theme.dark }

    $window.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString($t.window_bg)
}

function Find-ParentTabItem {
    param([object]$child)

    while ($child -ne $null -and $child.GetType().Name -ne "TabItem") {
        $child = [System.Windows.Media.VisualTreeHelper]::GetParent($child)
    }

    return $child
}

Apply-Theme $Config["THEME"]

# ---------- 4. UTILITAIRES ÉDITEUR / ONGLET ----------

function Get-ActiveEditor {
    if (-not $Tabs.SelectedItem) { return $null }
    return $Tabs.SelectedItem.Content
}

function New-Tab {
    $tabCount = $Tabs.Items.Count + 1

    # Créer l’onglet
    $tab = New-Object System.Windows.Controls.TabItem

    # Header = texte + bouton fermer
    $headerPanel = New-Object System.Windows.Controls.StackPanel
    $headerPanel.Orientation = "Horizontal"

    $titleBlock = New-Object System.Windows.Controls.TextBlock
    $titleBlock.Text = "Unlited $tabCount"
    $titleBlock.Margin = "0,0,5,0"
    $titleBlock.VerticalAlignment = "Center"

    $closeBtn = New-Object System.Windows.Controls.Button
    $closeBtn.Content = "x"
    $closeBtn.Width = 18
    $closeBtn.Height = 18
    $closeBtn.Padding = "0"
    $closeBtn.Margin = "5,0,0,0"
    $closeBtn.Background = [System.Windows.Media.Brushes]::Transparent
    $closeBtn.BorderThickness = "0"
    $closeBtn.Cursor = "Hand"

    # On stocke directement le TabItem dans le bouton
    $closeBtn.Tag = $tab

    $headerPanel.Children.Add($titleBlock) | Out-Null
    $headerPanel.Children.Add($closeBtn)   | Out-Null

    $tab.Header = $headerPanel

    # Zone d’édition
    $editor = New-Object System.Windows.Controls.RichTextBox
    $editor.VerticalScrollBarVisibility = "Auto"
    $editor.SpellCheck.IsEnabled = $true
    $tab.Content = $editor

    # Ajouter l’onglet
    $Tabs.Items.Add($tab) | Out-Null
    $Tabs.SelectedItem = $tab

    # Fermeture de l’onglet (méthode la plus fiable)
    $closeBtn.Add_Click({
        param($sender, $e)

        $tabToClose = $sender.Tag
        if ($tabToClose -ne $null) {
            $Tabs.Items.Remove($tabToClose)
        }
    })

    # Événements éditeur
    $editor.Add_TextChanged({
        Update-WordCount
        Mark-TabModified
    })

    $editor.Add_SelectionChanged({
        Update-CaretPosition
    })
}

function Update-WordCount {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $range = New-Object System.Windows.Documents.TextRange(
        $editor.Document.ContentStart,
        $editor.Document.ContentEnd
    )

    $text = $range.Text.Trim()
    $wordCount = if ($text -eq "") { 0 } else { ($text -split "\s+").Count }

    $StatusWords.Text = "Mots : $wordCount"
}

function Update-CaretPosition {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $caret = $editor.CaretPosition
    $lineStart = $caret.GetLineStartPosition(0)
    $lineNumber = 1
    while ($lineStart.GetLineStartPosition(-1) -ne $null) {
        $lineStart = $lineStart.GetLineStartPosition(-1)
        $lineNumber++
    }

    $column = $caret.GetOffsetToPosition($caret.GetLineStartPosition(0)) + 1
    $StatusPos.Text = "Line $lineNumber, Colonne $column"
}

function Mark-TabModified {
    if (-not $Tabs.SelectedItem) { return }

    $tab = $Tabs.SelectedItem
    $headerPanel = $tab.Header

    # Le premier enfant = TextBlock
    $titleBlock = $headerPanel.Children[0]

    if ($titleBlock.Text -notlike "*`**") {
        $titleBlock.Text += "*"
    }
}

# ---------- 5. OUVRIR / ENREGISTRER RTF ----------

function Save-Document {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Filter = "Rich Text Format (*.rtf)|*.rtf"
    $dialog.Title  = "Save/Anregistre .rtf"

    if ($dialog.ShowDialog() -eq "OK") {

        $range = New-Object System.Windows.Documents.TextRange(
            $editor.Document.ContentStart,
            $editor.Document.ContentEnd
        )

        $fs = New-Object System.IO.FileStream(
            $dialog.FileName,
            [System.IO.FileMode]::Create,
            [System.IO.FileAccess]::Write
        )

        $range.Save($fs, [System.Windows.DataFormats]::Rtf)
        $fs.Close()

        $tab = $Tabs.SelectedItem
        $tab.Header = [System.IO.Path]::GetFileName($dialog.FileName)
    }
}

function Open-Document {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = "Rich Text Format (*.rtf)|*.rtf"
    $dialog.Title  = "Open/Ouvrir .rtf"

    if ($dialog.ShowDialog() -eq "OK") {
        New-Tab
        $editor = Get-ActiveEditor

        $range = New-Object System.Windows.Documents.TextRange(
            $editor.Document.ContentStart,
            $editor.Document.ContentEnd
        )

        $fs = [System.IO.File]::OpenRead($dialog.FileName)
        $range.Load($fs, [System.Windows.DataFormats]::Rtf)
        $fs.Close()

        $tab = $Tabs.SelectedItem
        $tab.Header = [System.IO.Path]::GetFileName($dialog.FileName)
    }
}

# ---------- 6. AUTO-SAUVEGARDE ----------

function AutoSave-Documents {
    foreach ($tab in $Tabs.Items) {
        $header = [string]$tab.Header
        if (-not $header.EndsWith("*")) { continue }

        $editor = $tab.Content
        $safeName = $header.TrimEnd("*")

        $filePath = Join-Path $AutoSaveFolder "$safeName.autosave.rtf"

        $range = New-Object System.Windows.Documents.TextRange(
            $editor.Document.ContentStart,
            $editor.Document.ContentEnd
        )

        $fs = New-Object System.IO.FileStream(
            $filePath,
            [System.IO.FileMode]::Create,
            [System.IO.FileAccess]::Write
        )

        $range.Save($fs, [System.Windows.DataFormats]::Rtf)
        $fs.Close()
    }
}

function Restore-AutoSaves {
    $autosaves = Get-ChildItem $AutoSaveFolder -Filter *.autosave.rtf -ErrorAction SilentlyContinue
    foreach ($file in $autosaves) {
        New-Tab
        $editor = Get-ActiveEditor

        $range = New-Object System.Windows.Documents.TextRange(
            $editor.Document.ContentStart,
            $editor.Document.ContentEnd
        )

        $fs = [System.IO.File]::OpenRead($file.FullName)
        $range.Load($fs, "RTF")
        $fs.Close()

        $tab = $Tabs.SelectedItem
        $tab.Header = $file.BaseName.Replace(".autosave","") + "*"
    }
}

$autoSaveTimer = New-Object System.Windows.Threading.DispatcherTimer
$intervalSec = [int]($Config["AUTOSAVE_INTERVAL"])
if ($intervalSec -le 0) { $intervalSec = 30 }
$autoSaveTimer.Interval = [TimeSpan]::FromSeconds($intervalSec)
$autoSaveTimer.Add_Tick({ AutoSave-Documents })
$autoSaveTimer.Start()

# ---------- 7. BARRE D’OUTILS DYNAMIQUE ----------

function New-ToolbarButton {
    param(
        [string]$iconFile,
        [scriptblock]$action
    )

    $btn = New-Object System.Windows.Controls.Button

    $imgPath = Join-Path $Root $iconFile
    if (Test-Path $imgPath) {
        $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
        $bitmap.BeginInit()
        $bitmap.UriSource = New-Object System.Uri($imgPath)
        $bitmap.EndInit()

        $img = New-Object System.Windows.Controls.Image
        $img.Source = $bitmap
        $img.Width = 20
        $img.Height = 20
        $btn.Content = $img
    } else {
        # Si l’icône n’existe pas, on met juste du texte
        $btn.Content = [System.IO.Path]::GetFileNameWithoutExtension($iconFile)
    }

    $btn.Padding = "2"
    $btn.Margin  = "2"
    $btn.Add_Click($action)
    return $btn
}

function Invoke-Bold {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }
    $selection = $editor.Selection
    if (-not $selection.IsEmpty) {
        $current = $selection.GetPropertyValue([System.Windows.Documents.TextElement]::FontWeightProperty)
        if ($current -eq [System.Windows.FontWeights]::Bold) {
            $selection.ApplyPropertyValue([System.Windows.Documents.TextElement]::FontWeightProperty, [System.Windows.FontWeights]::Normal)
        } else {
            $selection.ApplyPropertyValue([System.Windows.Documents.TextElement]::FontWeightProperty, [System.Windows.FontWeights]::Bold)
        }
    }
}

function Invoke-Italic {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }
    $selection = $editor.Selection
    if (-not $selection.IsEmpty) {
        $current = $selection.GetPropertyValue([System.Windows.Documents.TextElement]::FontStyleProperty)
        if ($current -eq [System.Windows.FontStyles]::Italic) {
            $selection.ApplyPropertyValue([System.Windows.Documents.TextElement]::FontStyleProperty, [System.Windows.FontStyles]::Normal)
        } else {
            $selection.ApplyPropertyValue([System.Windows.Documents.TextElement]::FontStyleProperty, [System.Windows.FontStyles]::Italic)
        }
    }
}

function Invoke-TextColor {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }
    $dialog = New-Object System.Windows.Forms.ColorDialog
    if ($dialog.ShowDialog() -eq "OK") {
        $color = $dialog.Color
        $brush = New-Object System.Windows.Media.SolidColorBrush (
            [System.Windows.Media.Color]::FromArgb($color.A, $color.R, $color.G, $color.B)
        )
        $selection = $editor.Selection
        if (-not $selection.IsEmpty) {
            $selection.ApplyPropertyValue([System.Windows.Documents.TextElement]::ForegroundProperty, $brush)
        }
    }
}

function Invoke-Highlight {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }
    $dialog = New-Object System.Windows.Forms.ColorDialog
    if ($dialog.ShowDialog() -eq "OK") {
        $color = $dialog.Color
        $brush = New-Object System.Windows.Media.SolidColorBrush (
            [System.Windows.Media.Color]::FromArgb($color.A, $color.R, $color.G, $color.B)
        )
        $selection = $editor.Selection
        if (-not $selection.IsEmpty) {
            $selection.ApplyPropertyValue([System.Windows.Documents.TextElement]::BackgroundProperty, $brush)
        }
    }
}

function Invoke-AlignLeft {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }
    $paragraph = $editor.CaretPosition.Paragraph
    if ($paragraph) { $paragraph.TextAlignment = "Left" }
}

function Invoke-AlignCenter {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }
    $paragraph = $editor.CaretPosition.Paragraph
    if ($paragraph) { $paragraph.TextAlignment = "Center" }
}

function Invoke-AlignRight {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }
    $paragraph = $editor.CaretPosition.Paragraph
    if ($paragraph) { $paragraph.TextAlignment = "Right" }
}

function Invoke-InsertImage {
    $editor = Get-ActiveEditor
    if (-not $editor) { return }

    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif"
    if ($dialog.ShowDialog() -eq "OK") {
        $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
        $bitmap.BeginInit()
        $bitmap.UriSource = New-Object System.Uri($dialog.FileName)
        $bitmap.EndInit()

        $image = New-Object System.Windows.Controls.Image
        $image.Source = $bitmap
        $image.Stretch = "Uniform"
        $image.MaxWidth = 400
        $image.MaxHeight = 400

        $container = New-Object System.Windows.Documents.BlockUIContainer($image)
        $editor.Document.Blocks.Add($container)
    }
}

function Build-Toolbar {
    $Toolbar.Items.Clear()

    foreach ($btnName in $ToolbarConfig.buttons) {
        switch ($btnName) {
            "new"        { $btn = New-ToolbarButton "icons\new.png"       { New-Tab } }
            "open"       { $btn = New-ToolbarButton "icons\open.png"      { Open-Document } }
            "save"       { $btn = New-ToolbarButton "icons\save.png"      { Save-Document } }
            "bold"       { $btn = New-ToolbarButton "icons\bold.png"      { Invoke-Bold } }
            "italic"     { $btn = New-ToolbarButton "icons\italic.png"    { Invoke-Italic } }
            "textcolor"  { $btn = New-ToolbarButton "icons\textcolor.png" { Invoke-TextColor } }
            "highlight"  { $btn = New-ToolbarButton "icons\highlight.png" { Invoke-Highlight } }
            "alignleft"  { $btn = New-ToolbarButton "icons\left.png"      { Invoke-AlignLeft } }
            "aligncenter"{ $btn = New-ToolbarButton "icons\center.png"    { Invoke-AlignCenter } }
            "alignright" { $btn = New-ToolbarButton "icons\right.png"     { Invoke-AlignRight } }
            "insertimage"{ $btn = New-ToolbarButton "icons\image.png"     { Invoke-InsertImage } }
            default      { continue }
        }
        $Toolbar.Items.Add($btn) | Out-Null
    }
}

Build-Toolbar

# ---------- 8. MENUS & RACCOURCIS ----------

$MenuNew.Add_Click({ New-Tab })
$MenuOpen.Add_Click({ Open-Document })
$MenuSave.Add_Click({ Save-Document })
$MenuQuit.Add_Click({ $window.Close() })

$MenuCopy.Add_Click({
    $editor = Get-ActiveEditor
    if ($editor) { $editor.Copy() }
})
$MenuPaste.Add_Click({
    $editor = Get-ActiveEditor
    if ($editor) { $editor.Paste() }
})
$MenuCut.Add_Click({
    $editor = Get-ActiveEditor
    if ($editor) { $editor.Cut() }
})

$MenuCustomizeToolbar.Add_Click({
    [System.Windows.MessageBox]::Show("Modifie toolbar.json puis relance MiniWriter.")
})

$window.Add_KeyDown({
    param($sender,$e)

    if ($e.KeyboardDevice.Modifiers -eq "Control" -and $e.Key -eq "B") {
        Invoke-Bold
        $e.Handled = $true
    }
    elseif ($e.KeyboardDevice.Modifiers -eq "Control" -and $e.Key -eq "I") {
        Invoke-Italic
        $e.Handled = $true
    }
    elseif ($e.KeyboardDevice.Modifiers -eq "Control" -and $e.Key -eq "S") {
        Save-Document
        $e.Handled = $true
    }
    elseif ($e.KeyboardDevice.Modifiers -eq "Control" -and $e.Key -eq "N") {
        New-Tab
        $e.Handled = $true
    }
    elseif ($e.KeyboardDevice.Modifiers -eq "Control" -and $e.Key -eq "O") {
        Open-Document
        $e.Handled = $true
    }
})

# ---------- 9. PLUGINS ----------

$pluginFolder = Join-Path $Root "plugins"
if (Test-Path $pluginFolder) {
    Get-ChildItem $pluginFolder -Filter *.ps1 -ErrorAction SilentlyContinue | ForEach-Object {
        . $_.FullName
    }
}

# ---------- 10. DÉMARRAGE ----------

New-Tab
Restore-AutoSaves

$window.ShowDialog() | Out-Null