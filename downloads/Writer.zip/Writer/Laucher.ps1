Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Drawing.Drawing2D

# === COULEURS ===
$color_bg      = [System.Drawing.ColorTranslator]::FromHtml("#202225")
$color_panel   = [System.Drawing.ColorTranslator]::FromHtml("#2F3136")
$color_text    = [System.Drawing.ColorTranslator]::FromHtml("#FFFFFF")

# === FEN�TRE ===
$form = New-Object System.Windows.Forms.Form
$form.Text = "Writer Extra"
$form.Width = 1000
$form.Height = 650
$form.StartPosition = "CenterScreen"
$form.BackColor = $color_bg
$form.FormBorderStyle = "FixedSingle"
$form.Icon = New-Object System.Drawing.Icon("$PSScriptRoot\icons\Writer.ico")

# === BARRE DE RECHERCHE ===
$searchPanel = New-Object System.Windows.Forms.Panel
$searchPanel.Width = 700
$searchPanel.Height = 40
$searchPanel.Left = 40
$searchPanel.Top = 20
$searchPanel.BackColor = $color_panel
$form.Controls.Add($searchPanel)

$searchIcon = New-Object System.Windows.Forms.PictureBox
$searchIcon.Width = 24
$searchIcon.Height = 24
$searchIcon.Left = 8
$searchIcon.Top = 8
$searchIcon.Image = [System.Drawing.Image]::FromFile("$PSScriptRoot\icons\loup.png")
$searchPanel.Controls.Add($searchIcon)

$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Width = 700
$searchBox.Height = 30
$searchBox.Left = 40
$searchBox.Top = 5
$searchBox.Font = "Segoe UI, 11"
$searchBox.BackColor = $color_panel
$searchBox.ForeColor = $color_text
$searchBox.BorderStyle = "None"
$searchPanel.Controls.Add($searchBox)

# === LISTE DES FICHIERS ===
$list = New-Object System.Windows.Forms.ListView
$list.View = "Details"
$list.FullRowSelect = $true
$list.Width = 700
$list.Height = 450
$list.Left = 40
$list.Top = 80
$list.BackColor = $color_panel
$list.ForeColor = $color_text
$list.BorderStyle = "FixedSingle"
$list.Columns.Add("Nom/Name", 700)
$list.Columns.Add("Type", 100)
$form.Controls.Add($list)

# === CHARGEMENT DES FICHIERS ===
function Load-Files {
    $list.Items.Clear()
    $folder = "$PSScriptRoot\autosave"

    if (!(Test-Path $folder)) { New-Item -ItemType Directory -Path $folder | Out-Null }

    Get-ChildItem $folder | ForEach-Object {
        $item = New-Object System.Windows.Forms.ListViewItem($_.Name)
        $item.SubItems.Add($_.Extension)
        $list.Items.Add($item)
    }
}

Load-Files

# === RECHERCHE DYNAMIQUE ===
$searchBox.Add_TextChanged({
    if ($searchBox.Text -eq "") {
        $searchIcon.Image = [System.Drawing.Image]::FromFile("$PSScriptRoot\icons\loup.png")
        Load-Files
        return
    }

    $searchIcon.Image = [System.Drawing.Image]::FromFile("$PSScriptRoot\icons\loup_after.png")

    $list.Items.Clear()
    $folder = "$PSScriptRoot\autosave"

    Get-ChildItem $folder | Where-Object { $_.Name -like "*$($searchBox.Text)*" } | ForEach-Object {
        $item = New-Object System.Windows.Forms.ListViewItem($_.Name)
        $item.SubItems.Add($_.Extension)
        $list.Items.Add($item)
    }
})

# === PANNEAU LAT�RAL TRANSPARENT AVEC D�GRAD� ===
$sidePanel = New-Object System.Windows.Forms.Panel
$sidePanel.Width = 200
$sidePanel.Height = 500
$sidePanel.Left = 760
$sidePanel.Top = 80
$sidePanel.BackColor = [System.Drawing.Color]::Transparent
$sidePanel.Region = New-Object System.Drawing.Region(
    (New-Object System.Drawing.Drawing2D.GraphicsPath)
)
$form.Controls.Add($sidePanel)

# Coins arrondis
$path = New-Object System.Drawing.Drawing2D.GraphicsPath
$path.AddArc(0,0,20,20,180,90)
$path.AddArc(180,0,20,20,270,90)
$path.AddArc(180,480,20,20,0,90)
$path.AddArc(0,480,20,20,90,90)
$path.CloseFigure()
$sidePanel.Region = New-Object System.Drawing.Region($path)

# D�grad� bleu ? vert
$sidePanel.Add_Paint({
    param($sender, $e)

    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $sender.ClientRectangle,
        [System.Drawing.Color]::FromArgb(58,160,255),  # bleu
        [System.Drawing.Color]::FromArgb(58,255,138),  # vert
        [System.Drawing.Drawing2D.LinearGradientMode]::Vertical
    )

    $pen = New-Object System.Drawing.Pen($brush, 3)
    $e.Graphics.SmoothingMode = "AntiAlias"
    $e.Graphics.DrawPath($pen, $path)
})

# === BOUTONS DANS LE PANNEAU ===
function New-AppButton($text, $icon, $borderColor) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Width = 160
    $btn.Height = 60
    $btn.Left = 20
    $btn.FlatStyle = "Flat"
    $btn.FlatAppearance.BorderSize = 2
    $btn.FlatAppearance.BorderColor = $borderColor
    $btn.BackColor = "Transparent"
    $btn.ForeColor = $color_text
    $btn.Font = "Segoe UI, 11, Bold"
    $btn.Image = [System.Drawing.Image]::FromFile($icon)
    $btn.ImageAlign = "MiddleLeft"
    $btn.TextAlign = "MiddleRight"
    $btn.Text = $text
    return $btn
}

$btnWriter = New-AppButton "Writer" "$PSScriptRoot\icons\writer.png" [System.Drawing.Color]::FromArgb(58,160,255)
$btnWriter.Top = 20
$btnWriter.Add_Click({
    Start-Process Writer.bat
})

$btnSheet = New-AppButton "Calc" "$PSScriptRoot\icons\sheet.png" [System.Drawing.Color]::FromArgb(58,255,138)
$btnSheet.Top = 100
$btnSheet.Add_Click({
    Start-Process Sheet.bat
})

$btnDraw = New-AppButton "Draw" "$PSScriptRoot\icons\Draw.png" [System.Drawing.Color]::FromArgb(58,255,138)
$btnDraw.Top = 180
$btnDraw.Add_Click({
    Start-Process Draw.bat
})

$btnDelete = New-AppButton "Delet" "$PSScriptRoot\icons\trash.png" [System.Drawing.Color]::Gray
$btnDelete.Top = 340
$btnDelete.Add_MouseEnter({ $btnDelete.FlatAppearance.BorderColor = [System.Drawing.Color]::Red })
$btnDelete.Add_MouseLeave({ $btnDelete.FlatAppearance.BorderColor = [System.Drawing.Color]::Gray })
$btnDelete.Add_Click({
    if ($list.SelectedItems.Count -eq 0) { return }
    $file = $list.SelectedItems[0].Text
    $path = "$PSScriptRoot\autosave\$file"
    if (Test-Path $path) { Remove-Item $path -Force }
    Load-Files
})

$btnClose = New-AppButton "Exit" "$PSScriptRoot\icons\close.png" [System.Drawing.Color]::Red
$btnClose.Top = 420
$btnClose.Add_Click({ $form.Close() })

$sidePanel.Controls.AddRange(@($btnWriter, $btnSheet, $btnDraw, $btnDelete, $btnClose))

# === LANCER ===
$form.ShowDialog()