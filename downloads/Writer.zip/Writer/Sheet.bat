@echo off
cd /d "%~dp0"
:: Varriable !
set "name=Sheet"
set "hide=hidden"

if exist %hide%.txt goto execut

echo >> %hide%.txt

cmd /c start /min Sheet.bat
exit
:execut
del %hide%.txt
:: Execution !
cd splash
if not exist ready.txt goto skip
del ready.txt
:skip
start splash.hta /splashtool.vbs
cd ..
PowerShell -ExecutionPolicy Bypass -File "%name%.ps1" /wait
exit > nul